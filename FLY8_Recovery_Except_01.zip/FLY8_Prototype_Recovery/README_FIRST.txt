FLY8 PROTOTYPE RECOVERY PACKAGE
================================

Purpose
-------
A reconstruction/evidence bundle for rebuilding the useful prototype behavior into the independent FLY8 Android project. It preserves the uploaded APK, a complete ZIP-level extraction, selected FLY8-relevant files, and analysis aids.

IMPORTANT: THIS IS NOT YET A FULL SOURCE DECOMPILATION.
The APK contains compiled DEX bytecode, not the original Android Studio/Kotlin project. This package includes the original classes.dex and searchable string dumps, but JADX/apktool were not available in the execution environment and downloading the decompiler was blocked. Therefore no claim is made that classes-dex-ascii-strings.txt is source code. A proper JADX pass is still required to generate approximate Java source and decode Android resources/manifest.

Folders
-------
01_original/              Exact uploaded APK copy.
02_apk_extracted/         Every file extracted from the APK ZIP container, unchanged.
03_fly8_relevant/         Selected manifest, DEX, resource table, customer guide, privacy/terms/license notices, and native libraries for FLY8 review.
04_analysis/              ZIP inventory, SHA-256 hash, DEX string dumps, and raw manifest strings.
05_blueprint/             User-provided FLY8 Prototype Reconstruction Blueprint DOCX.

Reconstruction guardrails
-------------------------
- Rebuild only the behaviors needed by FLY8; do not ship the prototype APK inside the new app.
- The supplied blueprint says FLY8 must not require activation, license gates, device-slot servers, or a remote licensing backend.
- Preserve useful flows: dashboard/instance management, sessions, Wireless debugging pairing/manual ports, optional Shizuku/root connection, recovery/rejoin, bounded logs, diagnostics, keyboard/full view, About/privacy/legal.
- The APK contains VirtualApp/Xposed-related components and an embedded Xposed installer APK. Treat these as investigation evidence, not automatically reusable product dependencies. Audit licenses and compatibility before reuse.
- The prototype and the existing FLY8 repository use different cloning architectures; do not assume native Android profiles reproduce VirtualApp-style virtualization.
- An APK does not contain the original source comments, Gradle modules, build history, backend database, private signing key, or server-side implementation.

Recommended next technical pass
------------------------------
1. Run JADX against 01_original/FLY8_final_v6_sign.apk and export decompiled sources/resources into a separate folder.
2. Decode resources and AndroidManifest.xml with JADX/apktool, then compare those results against the included customer guide and the blueprint.
3. Map each needed behavior to the existing FLY8-Clone source architecture; reimplement behavior at its abstractions rather than wholesale transplanting opaque compiled code.
4. Test on a device and mark each feature Implemented, Verified on device, Blocked by platform, or Deferred.

Source APK SHA-256 is recorded in 04_analysis/SHA256SUMS.txt.
